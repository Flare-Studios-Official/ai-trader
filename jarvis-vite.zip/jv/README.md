# JARVIS Command Centre (v0.2, React + TypeScript + Vite + Three.js)
Run: `npm install && npm run dev` (needs Node 18+). Check types: `npm run typecheck`. Build: `npm run build`.
Mobile testing: `npm run dev` prints a LAN URL, but browsers block the microphone on plain http LAN addresses. To test voice on iPad/Android, deploy the `dist` folder to any HTTPS host (Netlify, Vercel, GitHub Pages) or open the project in StackBlitz/CodeSandbox from a mobile browser.
Structure: `commands/` (provider interface, rules, pipeline, executors) · `voice/` (Listener, Speaker) · `reactor/` (Three.js scene) · `components/` · `App.tsx`.
Swap AI later: implement `CommandProvider` (it only returns a Plan, never executes). Real actions need an `Executor` registered for `real` in `commands/pipeline.ts`; none exist, so real mode refuses everything.
Status: NOT yet installed, compiled, or run. No automated tests exist.
