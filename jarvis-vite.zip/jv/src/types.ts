export type State='idle'|'listening'|'thinking'|'speaking'|'executing'|'success'|'error';
export type Mode='demo'|'real';
export type Kind='info'|'sim'|'ok'|'bad';
export type Quality='low'|'med'|'high';
export interface Ev{id:number;t:string;title:string;detail?:string;kind:Kind}
export interface Msg{id:number;t:string;role:'user'|'jarvis';text:string;err?:boolean;demo?:boolean}
export interface Device{id:string;name:string;status:'Connected'|'Disconnected'|'Unavailable'|'Pairing'|'Busy'|'Permission required';note:string;targetable:boolean}
export interface Plan{tool:string;label?:string;arg?:string;local?:boolean;sensitive?:boolean;blocked?:string;unsupported?:string}
export interface Ctx{mode:Mode;voice:boolean;device:Device;devices:Device[]}
/** Replace this to plug in a secure backend LLM later. It must only return a Plan; it never executes anything. */
export interface CommandProvider{id:string;label:string;interpret(text:string,sig:AbortSignal):Promise<Plan>;examples():string[]}
