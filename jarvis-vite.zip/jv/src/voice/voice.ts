import {AbortErr} from '../util';
export class Speaker{
 pulse=0;supported=typeof speechSynthesis!=='undefined';
 speak(text:string,sig:AbortSignal):Promise<void>{
  if(!this.supported)return Promise.resolve();
  return new Promise((res,rej)=>{
   if(sig.aborted)return rej(new AbortErr());
   speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);let done=false;
   const fin=(err:boolean)=>{if(done)return;done=true;clearTimeout(to);sig.removeEventListener('abort',ab);err?rej(new AbortErr()):res()};
   const ab=()=>{speechSynthesis.cancel();fin(true)};const to=setTimeout(()=>fin(false),Math.max(5000,text.length*110));
   sig.addEventListener('abort',ab);u.onboundary=()=>{this.pulse=1};u.onend=()=>fin(false);u.onerror=()=>fin(false);speechSynthesis.speak(u)})}
 cancel(){if(this.supported)speechSynthesis.cancel()}
 /** Synthetic pulse from speech boundary events. Real output amplitude is not available from the Web Speech API. */
 level(){this.pulse*=.92;return this.pulse*.8}
}
export interface ListenCb{onStart():void;onText(t:string):void;onEnd(had:boolean):void;onError(m:string):void;onLevelMode(m:'live'|'unavailable'):void}
export class Listener{
 private gen=0;private rec:any=null;private stream:MediaStream|null=null;private ctx:AudioContext|null=null;private an:AnalyserNode|null=null;private buf:Uint8Array|null=null;private text='';
 get active(){return this.rec!==null}
 start(cb:ListenCb){const w=window as any,SR=w.SpeechRecognition||w.webkitSpeechRecognition;
  if(!SR){cb.onError('Speech recognition is not supported in this browser. Please type your command.');return}
  this.stop();const g=++this.gen;this.text='';const rec=new SR();this.rec=rec;rec.lang=navigator.language||'en-US';rec.interimResults=true;
  rec.onstart=()=>{if(g===this.gen)cb.onStart()};
  rec.onresult=(e:any)=>{if(g!==this.gen)return;let t='';for(const r of e.results)t+=r[0].transcript;this.text=t;cb.onText(t)};
  rec.onerror=(e:any)=>{if(g===this.gen)cb.onError(/not-allowed|service/.test(e.error)?'Microphone permission denied. JARVIS only listens when you press the mic. Allow it in browser settings, or type instead.':'Speech error: '+e.error)};
  rec.onend=()=>{if(g!==this.gen)return;this.rec=null;this.closeAudio();cb.onEnd(!!this.text.trim())};
  try{rec.start()}catch{this.rec=null;cb.onError('Could not start the microphone.');return}
  void this.openAudio(g,cb)}
 stop(){this.gen++;const r=this.rec;this.rec=null;try{r?.abort()}catch{}this.closeAudio()}
 private async openAudio(g:number,cb:ListenCb){
  if(!navigator.mediaDevices?.getUserMedia){cb.onLevelMode('unavailable');return}
  try{const s=await navigator.mediaDevices.getUserMedia({audio:true});if(g!==this.gen){s.getTracks().forEach(t=>t.stop());return}
   const AC=window.AudioContext||(window as any).webkitAudioContext,ctx=new AC(),an=ctx.createAnalyser();an.fftSize=256;
   ctx.createMediaStreamSource(s).connect(an);this.stream=s;this.ctx=ctx;this.an=an;this.buf=new Uint8Array(an.fftSize);cb.onLevelMode('live')}
  catch{if(g===this.gen)cb.onLevelMode('unavailable')}}
 private closeAudio(){this.stream?.getTracks().forEach(t=>t.stop());this.stream=null;this.ctx?.close().catch(()=>{});this.ctx=null;this.an=null;this.buf=null}
 level():number|null{if(!this.an||!this.buf)return null;this.an.getByteTimeDomainData(this.buf as any);let s=0;for(const v of this.buf)s+=Math.abs(v-128);return Math.min(1,s/this.buf.length/28)}
}
