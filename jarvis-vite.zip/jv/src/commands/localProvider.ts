import type {CommandProvider,Ctx,Plan} from '../types';
interface Rule{tool:string;label:string;example:string;re:RegExp;local?:boolean;sensitive?:boolean;blocked?:string}
const RULES:Rule[]=[
 {tool:'help',label:'help',example:'help',re:/^(help|what can you do|commands?|examples?)\b/,local:true},
 {tool:'clock',label:'clock',example:'what time is it',re:/^(what('?s| is) the |what |tell me the |current )?(time|date|day)\b/,local:true},
 {tool:'status',label:'status',example:'system status',re:/^(system )?(status|report|diagnostics?)\b/,local:true},
 {tool:'open_app',label:'open app',example:'open notepad',re:/^(open|launch|start)\s+(.+)/},
 {tool:'web_search',label:'web search',example:'search for cheap flights',re:/^(search(\s+for)?|google|look up)\s+(.+)/},
 {tool:'screenshot',label:'screenshot',example:'take a screenshot',re:/^(take (a )?)?screenshot\b/,sensitive:true},
 {tool:'delete_file',label:'delete file',example:'delete old-report.pdf',re:/^(delete|remove)\s+(.+)/,sensitive:true},
 {tool:'shell',label:'shell',example:'run <anything>',re:/^(run|execute)\s+(.+)/,blocked:'Arbitrary commands are never executed. Only predefined tools will exist.'},
];
export class LocalProvider implements CommandProvider{
 id='local-rules';label='local rule parser, no AI model';
 examples(){return RULES.filter(r=>!r.blocked).map(r=>r.example)}
 async interpret(text:string):Promise<Plan>{
  const s=text.toLowerCase().trim().replace(/^(jarvis[,:]?\s*)?(please\s+)?/,'').replace(/[.!?]+$/,'');
  for(const r of RULES){const m=s.match(r.re);if(m)return{tool:r.tool,label:r.label,arg:m.length>2?m[m.length-1]:undefined,local:r.local,sensitive:r.sensitive,blocked:r.blocked}}
  return{tool:'unsupported',unsupported:`I don’t understand “${text.slice(0,40)}”. This prototype uses fixed rules, not AI. Try: ${this.examples().slice(0,5).join(' · ')}.`}}
}
export function runLocal(p:Plan,c:Ctx,ex:string[]):string{
 if(p.tool==='help')return 'Supported: '+ex.join(' · ')+'. Device actions are simulated in Demo mode.';
 if(p.tool==='clock')return 'It is '+new Date().toLocaleString()+'.';
 return `Mode: ${c.mode}. Devices connected: ${c.devices.filter(d=>d.status==='Connected').length} of ${c.devices.length}. AI: local rule parser (no model).`}
