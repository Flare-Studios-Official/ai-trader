import type {CommandProvider,Ctx,Device,Kind,Mode,Plan,State} from '../types';
import {AbortErr,chk,wait} from '../util';
import {runLocal} from './localProvider';
export interface Hooks{ev(t:string,d?:string,k?:Kind):void;state(s:State):void;say(r:'user'|'jarvis',t:string,err?:boolean):void;
 approve(t:string,s:AbortSignal):Promise<boolean>;progress(p:number|null):void;speak(t:string,s:AbortSignal):Promise<void>}
/** Real executors must confirm outcomes themselves. Only a real executor may produce a verified result. */
export interface Executor{simulated:boolean;run(p:Plan,d:Device,s:AbortSignal,prog:(n:number)=>void):Promise<void>}
const demo:Executor={simulated:true,async run(_p,_d,s,prog){for(let i=0;i<=10;i++){prog(i/10);await wait(130,s)}}};
export const EXECUTORS:Partial<Record<Mode,Executor>>={demo}; // 'real' intentionally empty until companions exist
export class Pipeline{
 private ctl?:AbortController;
 constructor(private provider:CommandProvider,private h:Hooks,private ctx:()=>Ctx){}
 cancel(){this.ctl?.abort();this.ctl=undefined}
 private async end(k:'success'|'error',reply:string,s:AbortSignal){const h=this.h;h.state(k);h.say('jarvis',reply,k==='error');await wait(900,s);
  if(k==='success'&&this.ctx().voice){h.state('speaking');await h.speak(reply,s)}h.state('idle')}
 async run(text:string){
  this.cancel();const ctl=new AbortController(),s=ctl.signal;this.ctl=ctl;const h=this.h,c=this.ctx();
  try{
   h.say('user',text);h.ev('Command received',text);h.state('thinking');await wait(600,s);
   const p=await this.provider.interpret(text,s);chk(s);h.ev('Request interpreted',`tool: ${p.tool} (${this.provider.label})`);
   if(p.unsupported)return await this.end('error',p.unsupported,s);
   if(p.blocked){h.ev('Blocked by policy',p.blocked,'bad');return await this.end('error','Refused. '+p.blocked,s)}
   if(p.local){h.ev('Executed locally in browser','No device involved','ok');return await this.end('success',runLocal(p,c,this.provider.examples()),s)}
   const d=c.device;h.ev('Device selected',`${d.name}: ${d.status}`);
   if(p.sensitive){h.ev('Permission requested',p.tool+(p.arg?' '+p.arg:''));const ok=await h.approve(`${p.label}${p.arg?' '+p.arg:''} on ${d.name}`,s);chk(s);
    if(!ok){h.ev('Denied by user','Nothing was executed','bad');return await this.end('error','Cancelled. Nothing was executed.',s)}h.ev('Approved by user')}
   const ex=EXECUTORS[c.mode];
   if(!ex){h.ev('Action blocked','Real-action mode has no connected tool. Nothing was executed.','bad');return await this.end('error','Nothing was executed. No connected tool is available for that.',s)}
   h.state('executing');h.ev('Action started','SIMULATED: '+p.tool+(p.arg?' → '+p.arg:''),'sim');
   await ex.run(p,d,s,n=>h.progress(n));chk(s);h.progress(null);
   h.ev('Simulated result','No real action was performed on any device.','sim');
   await this.end('success',`[DEMO] Simulated ${p.label}${p.arg?` “${p.arg}”`:''}. No device was controlled.`,s)
  }catch(e){if(e instanceof AbortErr)return;h.progress(null);h.ev('Internal error',String(e),'bad');h.state('error');await wait(1200,s).catch(()=>{});if(!s.aborted)h.state('idle')}
  finally{if(this.ctl===ctl)this.ctl=undefined}}
}
