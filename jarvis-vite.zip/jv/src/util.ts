export class AbortErr extends Error{constructor(){super('aborted')}}
export const chk=(s:AbortSignal)=>{if(s.aborted)throw new AbortErr()};
export const wait=(ms:number,sig:AbortSignal)=>new Promise<void>((res,rej)=>{
 if(sig.aborted)return rej(new AbortErr());
 const a=()=>{clearTimeout(t);rej(new AbortErr())};
 const t=setTimeout(()=>{sig.removeEventListener('abort',a);res()},ms);sig.addEventListener('abort',a,{once:true})});
export const stamp=()=>new Date().toLocaleTimeString([], {hour12:false});
