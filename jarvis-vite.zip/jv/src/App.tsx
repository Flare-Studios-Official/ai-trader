import {useCallback,useEffect,useMemo,useRef,useState} from 'react';
import {ReactorView} from './components/Reactor';
import {Chat,Devices,Settings,Timeline} from './components/Panels';
import {LocalProvider} from './commands/localProvider';
import {Pipeline,type Hooks} from './commands/pipeline';
import {Listener,Speaker} from './voice/voice';
import {stamp} from './util';
import type {Device,Ev,Kind,Mode,Msg,Quality,State} from './types';
const DEVS:Device[]=[
 {id:'pc',name:'Windows PC',status:'Disconnected',note:'No companion installed (Stage 6).',targetable:true},
 {id:'and',name:'Android phone',status:'Disconnected',note:'No companion installed (Stage 7).',targetable:true},
 {id:'ipad',name:'iPad (this device)',status:'Unavailable',note:'Command centre only. Cannot be an action target.',targetable:false}];
const MSGS:Record<State,string>={idle:'SYSTEMS READY',listening:'LISTENING',thinking:'PROCESSING COMMAND',speaking:'SPEAKING',executing:'EXECUTING',success:'ACTION VERIFIED',error:'FAULT DETECTED'};
let uid=0;
export default function App(){
 const [st,setSt]=useState<State>('idle'),[mode,setMode]=useState<Mode>('demo'),[q,setQ]=useState<Quality>('med'),[voice,setVoice]=useState(true);
 const [rm,setRm]=useState(()=>matchMedia('(prefers-reduced-motion:reduce)').matches),[msgs,setMsgs]=useState<Msg[]>([]),[evs,setEvs]=useState<Ev[]>([]);
 const [sel,setSel]=useState('pc'),[input,setInput]=useState(''),[note,setNote]=useState('Push-to-talk only. JARVIS does not listen in the background.'),[mic,setMic]=useState(false);
 const [aud,setAud]=useState('NO AUDIO SIGNAL'),[prog,setProg]=useState<number|null>(null),[tab,setTab]=useState('t1'),[open,setOpen]=useState(false),[clock,setClock]=useState(stamp());
 const [approval,setApproval]=useState<{text:string;fin:(v:boolean)=>void}|null>(null);
 const stR=useRef(st),modeR=useRef(mode),voiceR=useRef(voice),selR=useRef(sel);stR.current=st;modeR.current=mode;voiceR.current=voice;selR.current=sel;
 const speaker=useMemo(()=>new Speaker(),[]),listener=useMemo(()=>new Listener(),[]),provider=useMemo(()=>new LocalProvider(),[]);
 const ev=useCallback((title:string,detail?:string,kind:Kind='info')=>setEvs(e=>[{id:++uid,t:stamp(),title,detail,kind},...e].slice(0,200)),[]);
 const hooks=useMemo<Hooks>(()=>({ev,state:s=>setSt(s),progress:p=>setProg(p),
  say:(role,text,err)=>setMsgs(m=>[...m,{id:++uid,t:stamp(),role,text,err,demo:role==='jarvis'&&modeR.current==='demo'}]),
  speak:(t,s)=>speaker.speak(t,s),
  approve:(text,sig)=>new Promise<boolean>(res=>{if(sig.aborted)return res(false);
   const fin=(v:boolean)=>{sig.removeEventListener('abort',ab);setApproval(null);res(v)};const ab=()=>fin(false);
   sig.addEventListener('abort',ab,{once:true});setApproval({text,fin});setTab('t2');setOpen(true)})}),[ev,speaker]);
 const pipe=useMemo(()=>new Pipeline(provider,hooks,()=>{const devices=DEVS;return{mode:modeR.current,voice:voiceR.current,devices,device:devices.find(d=>d.id===selR.current)!}}),[provider,hooks]);
 useEffect(()=>{const t=setInterval(()=>setClock(stamp()),1000);return()=>clearInterval(t)},[]);
 useEffect(()=>{document.body.classList.toggle('rm',rm)},[rm]);
 useEffect(()=>{ev('System initialised','Interface loaded.');setMsgs([{id:++uid,t:stamp(),role:'jarvis',demo:true,text:'Systems ready. Prototype in Demo mode: no real devices are controlled. Say or type help.'}]);
  return()=>{pipe.cancel();listener.stop();speaker.cancel()}},[ev,pipe,listener,speaker]);
 const interrupt=useCallback((label?:string)=>{const was=stR.current!=='idle';pipe.cancel();listener.stop();speaker.cancel();setMic(false);setProg(null);setApproval(null);setSt('idle');
  if(was)ev(label||'Interrupted','Cancelled by user','bad');setNote('Stopped.')},[pipe,listener,speaker,ev]);
 const send=()=>{const v=input.trim();if(!v)return;setInput('');listener.stop();setMic(false);void pipe.run(v)};
 const toggleMic=()=>{if(listener.active){listener.stop();setMic(false);setSt('idle');setNote('Microphone closed.');return}
  pipe.cancel();speaker.cancel();setApproval(null);
  listener.start({onStart:()=>{setSt('listening');setMic(true);ev('Microphone opened','Push-to-talk. Listening only until stopped.');setNote('Listening…')},
   onText:setInput,onLevelMode:m=>setAud(m==='live'?'LIVE MIC LEVEL':'MIC LEVEL UNAVAILABLE'),
   onEnd:had=>{setMic(false);setAud('NO AUDIO SIGNAL');setSt('idle');setNote(had?'Transcript ready. Review it, then press Send.':'Nothing heard.')},
   onError:m=>{setNote(m);setMic(false);setSt('idle')}})};
 const getLevel=useCallback(()=>{const l=listener.level();if(l!==null)return l;const s=stR.current;return s==='speaking'?speaker.level():s==='listening'?.2:s==='thinking'?.3:s==='executing'?.4:0},[listener,speaker]);
 const dev=DEVS.find(d=>d.id===sel)!,connected=DEVS.filter(d=>d.status==='Connected').length;
 const changeMode=(m:Mode)=>{setMode(m);ev('Mode changed',m==='demo'?'Demo: actions are simulated':'Real: only connected tools can act. None exist yet.')};
 return<div id="app">
 <header><span className="logo">J.A.R.V.I.S</span><span className="chip">{clock}</span>
  <span className={'chip '+(mode==='demo'?'demo':'real')}>{mode==='demo'?'DEMO — NO REAL DEVICE ACTIONS':'REAL-ACTION MODE — NO TOOLS CONNECTED'}</span><span className="sp"/>
  <span className="chip">AI: LOCAL RULE PARSER</span><span className="chip">TARGET: {dev.name.toUpperCase()} · {dev.status.toUpperCase()}</span>
  <button id="panelBtn" aria-expanded={open} onClick={()=>setOpen(o=>!o)}>PANELS</button>
  <button style={{borderColor:'#ff6b5a',color:'#ffb3a8'}} onClick={()=>interrupt('Emergency stop')} aria-label="Emergency stop">E-STOP</button></header>
 <div id="body"><div id="stage"><div id="view">
  <ReactorView state={st} quality={q} reduced={rm} getLevel={getLevel}/>
  <div className="stats"><div className="stat"><b>{msgs.filter(m=>m.role==='user').length}</b><span>COMMANDS</span></div><div className="stat"><b>{evs.length}</b><span>TIMELINE EVENTS</span></div>
   <div className="stat"><b>{evs.filter(e=>e.kind==='bad').length}</b><span>FAULTS</span></div><div className="stat"><b>{connected}/{DEVS.length}</b><span>DEVICES CONNECTED</span></div>
   <ul id="mini">{evs.slice(0,10).map(e=><li key={e.id}>{e.t} {e.title.toUpperCase()}</li>)}</ul></div>
  <div id="hudtxt"><div id="msg">{MSGS[st]}</div><div id="sub" className="mono">{st.toUpperCase()} · {aud}</div>
   <div id="prog" style={{display:prog===null?'none':'block'}}><i style={{width:((prog??0)*100)+'%'}}/></div>
   {prog!==null&&<div id="sub" className="mono">SIMULATED PROGRESS</div>}</div></div>
  <div className="cmd"><div className="row">
   <button id="mic" className={mic?'on':''} onClick={toggleMic} aria-label="Push to talk" aria-pressed={mic}><svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg></button>
   <input id="in" value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} autoComplete="off" placeholder="Type a command. Try: help" aria-label="Command"/>
   <button onClick={send} disabled={!input.trim()}>SEND</button><button id="stop" onClick={()=>interrupt()} aria-label="Interrupt">STOP</button></div>
   <div id="note" role="status" aria-live="polite">{note}</div></div></div>
 <aside id="panel" className={open?'open':''}>
  <div className="tabs" role="tablist">{[['t1','TIMELINE'],['t2','CHAT'],['t3','DEVICES'],['t4','SETTINGS']].map(([k,l])=><button key={k} role="tab" aria-selected={tab===k} onClick={()=>setTab(k)}>{l}</button>)}</div>
  <div className={'tab '+(tab==='t1'?'on':'')}><Timeline evs={evs}/></div>
  <div className={'tab '+(tab==='t2'?'on':'')}><Chat msgs={msgs} approval={approval}/></div>
  <div className={'tab '+(tab==='t3'?'on':'')}><Devices devs={DEVS} sel={sel} onSel={setSel}/></div>
  <div className={'tab '+(tab==='t4'?'on':'')}><Settings mode={mode} setMode={changeMode} q={q} setQ={setQ} voice={voice} setVoice={v=>{setVoice(v);if(!v)speaker.cancel()}} rm={rm} setRm={setRm} providerLabel={provider.label} clear={()=>{setMsgs([]);setEvs([])}}/></div></aside></div></div>}
