import type {Device,Ev,Msg,Quality,Mode} from '../types';
const TAG={sim:'SIMULATED',ok:'VERIFIED',bad:'FAILED',info:'EVENT'};
export const Timeline=({evs}:{evs:Ev[]})=><ul className="tl">{evs.map(e=><li key={e.id} className={'e '+e.kind}><i/><div><b>{e.title}<em className="tg">{TAG[e.kind]}</em></b><span>{e.detail}</span></div><time>{e.t}</time></li>)}</ul>;
export const Chat=({msgs,approval}:{msgs:Msg[];approval:{text:string;fin:(v:boolean)=>void}|null})=><div id="chat">
 {msgs.map(m=><div key={m.id} className={'m '+(m.role==='user'?'u ':'')+(m.err?'err':'')}><small>{m.role==='user'?'YOU':'JARVIS'} · {m.t}{m.demo?' · DEMO':''}</small><p>{m.text}</p></div>)}
 {approval&&<div className="m"><small>APPROVAL REQUIRED</small><p>{approval.text}. This is a sensitive action.<br/><button onClick={()=>approval.fin(true)}>APPROVE</button> <button onClick={()=>approval.fin(false)}>DENY</button></p></div>}</div>;
export const Devices=({devs,sel,onSel}:{devs:Device[];sel:string;onSel:(id:string)=>void})=><div>
 {devs.map(d=><div key={d.id} className={'card'+(d.id===sel?' sel':'')}><h4><input type="radio" name="dv" checked={d.id===sel} disabled={!d.targetable} onChange={()=>onSel(d.id)} aria-label={'Select '+d.name}/><span>{d.name}</span><span className="st">{d.status.toUpperCase()}</span></h4><p>{d.note}</p>
  <button disabled title="Companion not built yet">PAIR</button> <button disabled title="No paired credentials">REVOKE</button></div>)}
 <p className="k" style={{color:'var(--dim)',fontSize:11}}>Nothing shows as connected until an authenticated companion exists (Stages 6–7).</p></div>;
interface SP{mode:Mode;setMode(m:Mode):void;q:Quality;setQ(q:Quality):void;voice:boolean;setVoice(v:boolean):void;rm:boolean;setRm(v:boolean):void;clear():void;providerLabel:string}
export const Settings=(p:SP)=><div>
 <div className="set"><div>Action mode<small>Demo simulates. Real executes only through connected tools (none exist yet).</small></div><select value={p.mode} onChange={e=>p.setMode(e.target.value as Mode)}><option value="demo">Demo</option><option value="real">Real-action</option></select></div>
 <div className="set"><div>Visual quality<small>Lower for older phones.</small></div><select value={p.q} onChange={e=>p.setQ(e.target.value as Quality)}><option value="low">Low</option><option value="med">Medium</option><option value="high">High</option></select></div>
 <div className="set"><div>Spoken responses<small>Browser text-to-speech.</small></div><input type="checkbox" checked={p.voice} onChange={e=>p.setVoice(e.target.checked)}/></div>
 <div className="set"><div>Reduced motion<small>Slows and calms the core.</small></div><input type="checkbox" checked={p.rm} onChange={e=>p.setRm(e.target.checked)}/></div>
 <div className="set"><div>AI provider<small>{p.providerLabel}. No API keys in this app.</small></div></div>
 <div className="set"><div>History<small>Kept in memory only.</small></div><button onClick={p.clear}>CLEAR</button></div></div>;
