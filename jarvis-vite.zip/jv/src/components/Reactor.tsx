import {useEffect,useRef,useState} from 'react';
import {createReactor,type ReactorApi} from '../reactor/reactor';
import type {Quality,State} from '../types';
interface P{state:State;quality:Quality;reduced:boolean;getLevel:()=>number}
export function ReactorView({state,quality,reduced,getLevel}:P){
 const cv=useRef<HTMLCanvasElement>(null),wf=useRef<HTMLCanvasElement>(null),api=useRef<ReactorApi|null>(null),hist=useRef<number[]>(new Array(75).fill(0)),lvl=useRef(getLevel),[fail,setFail]=useState(false);
 lvl.current=getLevel;const init=useRef({state,quality,reduced});init.current={state,quality,reduced};
 useEffect(()=>{const a=createReactor({canvas:cv.current!,getLevel:()=>lvl.current(),onLost:()=>setFail(true),
   onFrame:(lv,css)=>{document.documentElement.style.setProperty('--c',css);const c=wf.current?.getContext('2d');if(!c)return;const h=hist.current;h.push(lv);h.shift();c.clearRect(0,0,300,92);c.fillStyle=css;h.forEach((v,i)=>{const b=2+v*88;c.fillRect(i*4,(92-b)/2,2,b)})}});
  if(!a){setFail(true);return}api.current=a;a.setQuality(init.current.quality);a.setReduced(init.current.reduced);a.setState(init.current.state);
  return()=>{a.dispose();api.current=null}},[]);
 useEffect(()=>{api.current?.setState(state);if(state==='thinking'||state==='listening')api.current?.ripple()},[state]);
 useEffect(()=>{api.current?.setQuality(quality)},[quality]);
 useEffect(()=>{api.current?.setReduced(reduced)},[reduced]);
 return<>
  <canvas id="cv" ref={cv} aria-label="Interactive 3D energy core"/>
  <div className="nogl" style={{display:fail?'grid':'none'}}><div><i/>3D core unavailable (WebGL missing or context lost). Voice and commands still work.</div></div>
  <div className="hud" aria-hidden="true">
   <svg className="a" viewBox="0 0 100 100"><circle cx="50" cy="50" r="48" strokeWidth=".15" strokeDasharray="1 .8"/><circle cx="50" cy="50" r="46.5" strokeWidth=".4" strokeDasharray="14 3 3 3"/></svg>
   <svg className="b" viewBox="0 0 100 100"><circle cx="50" cy="50" r="44" strokeWidth=".25" strokeDasharray="30 6"/><circle cx="50" cy="50" r="42" strokeWidth=".12"/></svg>
  </div>
  <canvas id="wf" ref={wf} width={300} height={92} aria-hidden="true"/></>}
