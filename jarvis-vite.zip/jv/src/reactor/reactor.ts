import * as THREE from 'three';
import type {Quality,State} from '../types';
export interface ReactorOpts{canvas:HTMLCanvasElement;getLevel:()=>number;onFrame?:(lv:number,css:string)=>void;onLost?:()=>void}
export interface ReactorApi{setState(s:State):void;setQuality(q:Quality):void;setReduced(r:boolean):void;ripple():void;dispose():void}
const COL:Record<State,[number,number,number]>={idle:[.1,.6,1],listening:[.2,.95,1],thinking:[.45,.5,1],speaking:[.3,.85,1],executing:[.25,.8,1],success:[.2,1,.7],error:[1,.55,.15]};
const SPD:Record<State,number>={idle:.3,listening:.55,thinking:2.2,speaking:.7,executing:1.5,success:.5,error:.2};
const QS={low:{d:1,n:900,o:2,arcs:false,lit:false},med:{d:1.5,n:2400,o:3,arcs:true,lit:true},high:{d:2,n:4200,o:4,arcs:true,lit:true}};
const VS='varying vec3 vN,vP,vV;void main(){vN=normalize(normalMatrix*normal);vP=position;vec4 mv=modelViewMatrix*vec4(position,1.);vV=-mv.xyz;gl_Position=projectionMatrix*mv;}';
const NOISE='float h(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}float vn(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);return mix(mix(mix(h(i),h(i+vec3(1,0,0)),f.x),mix(h(i+vec3(0,1,0)),h(i+vec3(1,1,0)),f.x),f.y),mix(mix(h(i+vec3(0,0,1)),h(i+vec3(1,0,1)),f.x),mix(h(i+vec3(0,1,1)),h(i+vec3(1,1,1)),f.x),f.y),f.z);}';
const PLASMA=NOISE+'uniform float t,k,q;uniform vec3 c;varying vec3 vN,vP,vV;float fbm(vec3 p){float a=.5,s=0.;for(int i=0;i<4;i++){if(float(i)>=q)break;s+=a*vn(p);p=p*2.03+7.1;a*=.5;}return s;}void main(){vec3 p=normalize(vP)*2.2;vec3 w=vec3(fbm(p+t*.15),fbm(p+5.2-t*.12),fbm(p+9.1+t*.1));float f=fbm(p+w*1.6+t*.08);float ridge=pow(1.-abs(f*2.-1.),6.);float nz=clamp(dot(normalize(vN),normalize(vV)),0.,1.);float rim=pow(1.-nz,2.5);vec3 hot=mix(c,vec3(1.),.75);vec3 col=mix(c*.18,c*.9,smoothstep(.2,.8,f));col+=hot*ridge*1.4;col=mix(col,hot,pow(nz,4.)*.6*k);col+=c*rim*.9+vec3(.35,.2,.9)*rim*rim*.35;gl_FragColor=vec4(col*k,1.);}';
const GLASS='uniform vec3 c,L;uniform float k,a;varying vec3 vN,vP,vV;void main(){vec3 n=normalize(vN),v=normalize(vV);float nz=clamp(dot(n,v),0.,1.);float f=pow(1.-nz,3.);vec3 tint=mix(c,vec3(.55,.35,1.),smoothstep(.4,1.,f));vec3 r=reflect(-v,n);float sp=pow(max(dot(r,normalize(L)),0.),40.);gl_FragColor=vec4((tint*f*1.2+vec3(1.)*sp*.9)*k,(f*.55+sp)*a);}';
function glow(){const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d')!,r=g.createRadialGradient(64,64,0,64,64,64);r.addColorStop(0,'rgba(255,255,255,.9)');r.addColorStop(.25,'rgba(255,255,255,.3)');r.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=r;g.fillRect(0,0,128,128);return new THREE.CanvasTexture(c)}
function ticks(r:number,n:number,l:number,m:THREE.Material){const p:number[]=[];for(let i=0;i<n;i++){const a=i/n*6.2832,q=i%5?l:l*2.2;p.push(Math.cos(a)*r,Math.sin(a)*r,0,Math.cos(a)*(r+q),Math.sin(a)*(r+q),0)}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));return new THREE.LineSegments(g,m)}

export function createReactor(o:ReactorOpts):ReactorApi|null{
 let R:THREE.WebGLRenderer;try{R=new THREE.WebGLRenderer({canvas:o.canvas,antialias:false,alpha:true,powerPreference:'high-performance'})}catch{return null}
 const scene=new THREE.Scene(),cam=new THREE.PerspectiveCamera(45,1,.1,100),core=new THREE.Group(),add=THREE.AdditiveBlending;scene.add(core);
 const U={t:{value:0},k:{value:1},q:{value:3},c:{value:new THREE.Vector3(.1,.6,1)},L:{value:new THREE.Vector3(1,1,2)}};
 const tint:(THREE.Material&{color:THREE.Color})[]=[];
 core.add(new THREE.Mesh(new THREE.SphereGeometry(1,48,32),new THREE.ShaderMaterial({uniforms:{t:U.t,k:U.k,q:U.q,c:U.c},vertexShader:VS,fragmentShader:PLASMA})));
 const glass=(r:number,a:number,side:THREE.Side)=>core.add(new THREE.Mesh(new THREE.SphereGeometry(r,40,28),new THREE.ShaderMaterial({uniforms:{c:U.c,k:U.k,L:U.L,a:{value:a}},vertexShader:VS,fragmentShader:GLASS,transparent:true,depthWrite:false,blending:add,side})));
 glass(1.45,1,THREE.FrontSide);glass(1.45,.5,THREE.BackSide);glass(1.9,.8,THREE.FrontSide);
 const wm=new THREE.LineBasicMaterial({transparent:true,opacity:.16,blending:add});tint.push(wm);
 const wire=new THREE.LineSegments(new THREE.WireframeGeometry(new THREE.IcosahedronGeometry(1.68,2)),wm);core.add(wire);
 const tex=glow(),sprites=[6,12].map((s,i)=>{const m=new THREE.SpriteMaterial({map:tex,transparent:true,blending:add,depthWrite:false,opacity:i?.18:.35});tint.push(m as any);const sp=new THREE.Sprite(m);sp.scale.setScalar(s);core.add(sp);return sp});
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(9,9),new THREE.MeshBasicMaterial({map:tex,transparent:true,blending:add,depthWrite:false,opacity:.35}));floor.rotation.x=-Math.PI/2;floor.position.y=-2.6;scene.add(floor);tint.push(floor.material as any);
 const key=new THREE.DirectionalLight(0xbfe4ff,2.2);key.position.set(3,4,5);const cl=new THREE.PointLight(0x33aaff,40,0,2);scene.add(key,cl,new THREE.AmbientLight(0x112244,.8));
 const beadG=new THREE.SphereGeometry(.045,8,8),beadM=new THREE.MeshBasicMaterial({blending:add,transparent:true});tint.push(beadM);
 const rd:[number,number[],number,number][]=[[2.3,[.4,0,.2],.5,6.283],[2.6,[1.2,.3,0],-.35,4.4],[2.95,[.2,1,.4],.25,5.3],[3.3,[1.4,0,1],-.2,3.7],[3.7,[.6,.6,.1],.12,6.283]];
 const rings=rd.map(([r,t,s,arc],i)=>{const std=new THREE.MeshStandardMaterial({metalness:.85,roughness:.32,emissiveIntensity:.35}),bas=new THREE.MeshBasicMaterial({transparent:true,opacity:.75,blending:add});tint.push(bas);
  const lm=new THREE.LineBasicMaterial({transparent:true,opacity:.5,blending:add});tint.push(lm);
  const mesh=new THREE.Mesh(new THREE.TorusGeometry(r,.008+i*.003,8,160,arc),std),bead=new THREE.Mesh(beadG,beadM),g=new THREE.Group();
  g.add(mesh,ticks(r-.12,90+i*10,.07,lm),bead);g.rotation.set(t[0],t[1],t[2]);core.add(g);return{g,s,r,mesh,std,bas,bead,a:i}});
 const N=4200,pp=new Float32Array(N*3);for(let i=0;i<N;i++){let x,y,z;if(Math.random()<.65){const r=3.2+Math.pow(Math.random(),1.5)*8,a=Math.random()*6.283;x=Math.cos(a)*r;z=Math.sin(a)*r;y=(Math.random()-.5)*r*.28}else{const r=2.4+Math.random()*3,u=Math.random()*2-1,a=Math.random()*6.283,q=Math.sqrt(1-u*u);x=q*Math.cos(a)*r;y=u*r;z=q*Math.sin(a)*r}pp.set([x,y,z],i*3)}
 const pg=new THREE.BufferGeometry();pg.setAttribute('position',new THREE.BufferAttribute(pp,3));const pm=new THREE.PointsMaterial({size:.04,transparent:true,opacity:.75,blending:add,depthWrite:false});tint.push(pm);const parts=new THREE.Points(pg,pm);scene.add(parts);
 const op=new Float32Array(450);for(let i=0;i<150;i++){const u=Math.random()*2-1,a=Math.random()*6.283,q=Math.sqrt(1-u*u),r=1.7+Math.random()*.5;op.set([q*Math.cos(a)*r,u*r,q*Math.sin(a)*r],i*3)}
 const og=new THREE.BufferGeometry();og.setAttribute('position',new THREE.BufferAttribute(op,3));const orb=new THREE.Points(og,new THREE.PointsMaterial({color:0xffffff,size:.05,transparent:true,opacity:.9,blending:add,depthWrite:false}));core.add(orb);
 const ripples=[0,1,2,3].map(()=>{const m=new THREE.MeshBasicMaterial({transparent:true,opacity:0,blending:add,depthWrite:false});tint.push(m);const r=new THREE.Mesh(new THREE.TorusGeometry(1,.008,6,128),m);r.visible=false;r.userData={on:false,p:0};core.add(r);return r});
 const AN=16,arcs=[0,1,2].map(()=>{const g=new THREE.BufferGeometry(),a=new THREE.BufferAttribute(new Float32Array(AN*3),3);a.setUsage(THREE.DynamicDrawUsage);g.setAttribute('position',a);const l=new THREE.Line(g,new THREE.LineBasicMaterial({transparent:true,opacity:0,blending:add,depthWrite:false}));l.frustumCulled=false;core.add(l);return l});
 const strike=(l:THREE.Line)=>{const a=l.geometry.attributes.position as THREE.BufferAttribute,u=Math.random()*2-1,ph=Math.random()*6.283,s=Math.sqrt(1-u*u),dx=s*Math.cos(ph),dy=u,dz=s*Math.sin(ph);
  for(let i=0;i<AN;i++){const r=1+i/(AN-1)*.9,j=i>0&&i<AN-1?.18:0;a.setXYZ(i,dx*r+(Math.random()-.5)*j,dy*r+(Math.random()-.5)*j,dz*r+(Math.random()-.5)*j)}a.needsUpdate=true;(l.material as THREE.LineBasicMaterial).opacity=.9};
 const comet=new THREE.Mesh(new THREE.SphereGeometry(.07,12,12),new THREE.MeshBasicMaterial({color:0xffffff,blending:add,transparent:true}));comet.visible=false;core.add(comet);
 const base=new THREE.Group();base.position.y=-2.6;base.rotation.x=Math.PI/2;const bm=new THREE.LineBasicMaterial({transparent:true,opacity:.5,blending:add});tint.push(bm);
 base.add(ticks(2.4,120,.08,bm),new THREE.Mesh(new THREE.RingGeometry(1.2,1.22,96),new THREE.MeshBasicMaterial({color:0x55bbff,transparent:true,opacity:.4,side:THREE.DoubleSide,blending:add})));scene.add(base);

 let st:State='idle',q:Quality='med',reduced=false,spd=.3,lv=0,raf=0,disposed=false,t0=0,arcT=0,frames=0,px=0,py=0,rx=0,ry=0;
 const cur=new THREE.Color().setRGB(...COL.idle),tgt=new THREE.Color(),tc=new THREE.Color(),white=new THREE.Color(1,1,1),clk=new THREE.Clock();
 const applyQ=()=>{const c=QS[q];R.setPixelRatio(Math.min(devicePixelRatio,c.d));pg.setDrawRange(0,c.n);U.q.value=c.o;rings.forEach(r=>{r.mesh.material=c.lit?r.std:r.bas});key.visible=cl.visible=c.lit;resize()};
 const resize=()=>{const p=o.canvas.parentElement,w=p?.clientWidth||1,h=p?.clientHeight||1;R.setSize(w,h,false);cam.aspect=w/h;cam.position.z=Math.max(8,7.4/cam.aspect);cam.updateProjectionMatrix()};
 const ro=new ResizeObserver(resize);if(o.canvas.parentElement)ro.observe(o.canvas.parentElement);
 const onMove=(e:PointerEvent)=>{px=e.clientX/innerWidth-.5;py=e.clientY/innerHeight-.5};addEventListener('pointermove',onMove);
 const onLost=(e:Event)=>{e.preventDefault();stop();o.onLost?.()};o.canvas.addEventListener('webglcontextlost',onLost);
 function frame(){raf=requestAnimationFrame(frame);const dt=Math.min(clk.getDelta(),.05);t0+=dt*(reduced?.4:1);
  tgt.setRGB(...COL[st]);cur.lerp(tgt,Math.min(1,dt*4));spd+=(SPD[st]*(reduced?.35:1)-spd)*Math.min(1,dt*2.5);
  lv+=(Math.min(1,o.getLevel())-lv)*.2;const k=1+.12*Math.sin(t0*1.4)+lv*.9+(st==='success'?.5:0);
  U.t.value=t0*(.6+spd);U.k.value=k;U.c.value.set(cur.r,cur.g,cur.b);U.L.value.set(Math.sin(t0*.3),.6,Math.cos(t0*.3)+1.6);
  tc.copy(cur).lerp(white,.25);tint.forEach(m=>m.color.copy(tc));cl.color.copy(cur);cl.intensity=30+lv*60;
  rings.forEach(r=>{r.g.rotation.z+=r.s*spd*dt*2;r.g.rotation.x+=Math.sin(t0*.3+r.a)*dt*.05*spd;r.std.color.copy(tc);r.std.emissive.copy(cur);
   r.a+=dt*(.6+spd)*(r.s>0?1:-1);r.bead.position.set(Math.cos(r.a)*r.r,Math.sin(r.a)*r.r,0)});
  wire.rotation.y+=dt*.15*spd;wire.rotation.x+=dt*.07*spd;orb.rotation.y+=dt*.5*spd;parts.rotation.y+=dt*.03*(.4+spd);
  const sc=st==='thinking'?.93+.05*Math.sin(t0*9):1+lv*.12;core.children.forEach(c=>{if((c as any).geometry?.parameters?.radius>1.4)c.scale.setScalar(sc)});
  sprites.forEach((s,i)=>s.scale.setScalar((i?12:6)*(1+lv*.25)));
  comet.visible=st==='executing';if(comet.visible){const a=t0*4;comet.position.set(Math.cos(a)*2.45,Math.sin(a)*.56*2.45,Math.sin(a)*.82*2.45)}
  ripples.forEach(r=>{const d=r.userData;if(d.on){d.p+=dt*.9;r.scale.setScalar(1+d.p*3);(r.material as THREE.MeshBasicMaterial).opacity=Math.max(0,.6*(1-d.p));if(d.p>=1){d.on=false;r.visible=false}}});
  if(st==='listening'&&lv>.12&&Math.random()<.06)api.ripple();
  arcT-=dt;if(arcT<0&&QS[q].arcs&&!reduced){arcT=.4+Math.random()*(st==='thinking'||st==='executing'?.6:2.5);strike(arcs[Math.floor(Math.random()*3)])}
  arcs.forEach(l=>{const m=l.material as THREE.LineBasicMaterial;m.opacity*=.9;m.color.copy(tc)});
  rx+=(py*.35-rx)*.05;ry+=(px*.5-ry)*.05;core.rotation.x=rx;core.rotation.y=ry+t0*.05;parts.rotation.x=rx*.5;base.rotation.z+=dt*.1;
  R.render(scene,cam);
  if(o.onFrame&&++frames%6===0)o.onFrame(lv,`rgb(${[cur.r,cur.g,cur.b].map(v=>Math.round(Math.min(1,v+.15)*255)).join(',')})`)}
 function start(){if(!raf&&!disposed){clk.getDelta();raf=requestAnimationFrame(frame)}}
 function stop(){if(raf)cancelAnimationFrame(raf);raf=0}
 const onVis=()=>document.hidden?stop():start();document.addEventListener('visibilitychange',onVis);
 const api:ReactorApi={setState:s=>{st=s},setQuality:v=>{q=v;applyQ()},setReduced:r=>{reduced=r},
  ripple(){const r=ripples.find(x=>!x.userData.on);if(r){r.userData.on=true;r.userData.p=0;r.visible=true;r.rotation.set(Math.random()*.6,Math.random()*.6,0)}},
  dispose(){disposed=true;stop();ro.disconnect();removeEventListener('pointermove',onMove);document.removeEventListener('visibilitychange',onVis);o.canvas.removeEventListener('webglcontextlost',onLost);
   scene.traverse(ob=>{const m=ob as any;m.geometry?.dispose();([] as any[]).concat(m.material||[]).forEach((x:any)=>x.dispose())});[tex,...rings.flatMap(r=>[r.std,r.bas])].forEach((x:any)=>x.dispose());R.dispose();R.forceContextLoss()}};
 applyQ();start();return api}
